#include "Game_Data.h"

Game::Game(){

}