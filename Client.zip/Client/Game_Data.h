

class Game{
public:
	Game();
};